# PROJECT: Booking a table on the Little Lemon website

### Third Party Libraries & APIs:
 - react-router-dom
 - react-responsive-carousel
 - Meta front-end table-booking API

### Install and Run:
 - Run 'npm install' and 'npm start' to get start.
 - Run 'npm test' to start jtest.